

<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Bootstrap demo</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
    <link rel="stylesheet" href="scss/style.css">
  </head>
  <body>
    <div class="container-fluid bg-login">
        <div class="row box-input">
            <form action="" method="POST">
            <h2>Register</h2>
              <div class="row">
                <div class="col-6">
                  <label for="nik">NIK</label><br>
                  <input type="text" name="nik" placeholder="Masukan nik" required><br>
                  <label for="nama">Nama</label><br>
                  <input type="text" name="nama" placeholder="Masukan nama" required><br>
                  <label for="telepon">Telepon</label><br>
                  <input type="text" name="telp" placeholder="Masukan telepon" required><br>
                </div>
                <div class="col-6">
                  <label for="username">Username</label><br>
                  <input type="text" name="username" placeholder="Masukan username" required><br>
                  <label for="password">Password</label><br>
                  <input type="text" name="password" placeholder="Masukan password" required><br>
                  <label for="cpassword">Ulangi Password</label><br>
                  <input type="text" name="cpassword" placeholder="Konfirmasi password" required>
                </div>
              </div>
                <button class="btn" name="submit">Register</button>
                <p>Sudah punya akun? <a href="login.php">Login</a></p>
            </form>
            <?php
            ?>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous"></script>
  </body>
</html>