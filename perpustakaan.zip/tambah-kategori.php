<?php
    require 'koneksi.php';

    
    $obj=new CrudKategori(); 
    if(isset($_POST["submit"])){
      $query = $obj->insertKategori($_POST["id"], $_POST["nama_kategori"]); 
    if($query>0){
      echo "<script>alert('Data Tersimpan');</script>";
      echo "<script>window.location='?halaman=kategori'</script>";
    }else{
        echo "error";
    }
    }
?>

<div class="container-fluid">

    <div class="card o-hidden border-0 shadow-lg">
        <div class="card-body p-0">
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-primary">Tambah Kategori</h6>
                        </div>
            <!-- Nested Row within Card Body -->
            <div class="p-5">
                <form class="user" method="POST">
                    <div class="form-group row">
                        <div class="col-12">
                            <input type="hidden" class="form-control" id="exampleFirstName" name="id"
                                placeholder="Masukan Id">
                        </div>
                        <div class="col-sm-6 mb-3 mb-sm-0">
                            <input type="text" class="form-control" id="exampleLastName" name="nama_kategori"
                                placeholder="Tambahkan Kategori">
                        </div>
                    
                    <button class="btn btn- btn-primary" name="submit" style="margin= auto;">Simpan</button>
                </form>
            </div>
        </div>
    </div>

</div>

<!-- Scroll to Top Button-->
<a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
</a>