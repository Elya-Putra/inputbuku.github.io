<?php
    require_once('koneksi.php');

    $obj = new CrudBuku;

    if(!$obj->detailDataBuku($_GET['id']))die("Error: id not found");
    $result = $obj->deleteBuku($_GET['id']);
    if($result==1){
        echo "<script>alert('Data berhasil dihapus');</script>";
        echo "<script>window.location='halaman-admin.php?halaman=tabel'</script>";
    }
?>

