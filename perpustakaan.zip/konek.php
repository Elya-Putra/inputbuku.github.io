<?php

$server = "localhost";
$user = "root";
$password = "";
$database = "belajar_buku";

$conn = mysqli_connect($server, $user, $password, $database);

if(!$conn){
    echo "gagal konek";
}

?>