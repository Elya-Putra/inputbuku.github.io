<?php
    require 'koneksi.php';

    
    $register=new Register(); 
    if(isset($_POST["submit"])){
      $result = $register->registration($_POST["id"], $_POST["nama"], $_POST["username"], $_POST["password"], $_POST["cpassword"], $_POST["level"]); 
    if($result==1){
      echo "<script>alert('Register Sukses');</script>";
    }
    elseif($result==10){
      echo "<script>alert('Username or Password Has Alrady Taken');</script>";
    }
    elseif($result==100){
      echo "<script>alert('Password does not match');</script>";
    }
    }
?>

<div class="container-fluid">

        <div class="card o-hidden border-0 shadow-lg">
            <div class="card-body p-0">
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-primary">Tambah User</h6>
                        </div>
                <!-- Nested Row within Card Body -->
                        <div class="p-5">
                            <form class="user" method="POST">
                                <div class="form-group row">
                                    <div class="col-sm-6 mb-3 mb-sm-0">
                                        <input type="text" class="form-control" id="exampleFirstName" name="id"
                                            placeholder="Masukan Id">
                                    </div>
                                    <div class="col-sm-6">
                                        <input type="text" class="form-control" id="exampleLastName" name="username"
                                            placeholder="Masukan Nama">
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <div class="col-sm-6 mb-3 mb-sm-0">
                                        <input type="text" class="form-control" id="exampleFirstName" name="nama"
                                            placeholder="Masukan Username">
                                    </div>
                                    <div class="col-sm-6">
                                        <input type="password" class="form-control" id="exampleLastName" name="password"
                                            placeholder="Masukan Password">
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <div class="col-sm-6 mb-3 mb-sm-0">
                                        <input type="password" class="form-control"
                                            id="exampleInputPassword" name="cpassword" placeholder="Konfirmasi Password">
                                    </div>
                                    <div class="col-sm-6">
                                        <select name="level" id="" class="form-control">
                                            <option disebel selected>Pilih Level</option>
                                            <option value="Admin">Admin</option>
                                            <option value="User">User</option>
                                        </select>
                                    </div>
                                </div> 
                            <button class="btn btn- btn-primary" name="submit" style="margin= auto;">Simpan</button>
                            </form>
                </div>
            </div>
        </div>

    </div>

<!-- Scroll to Top Button-->
<a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
</a>