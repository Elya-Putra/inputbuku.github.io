<?php
require_once 'koneksi.php'; 
require_once('koneksi.php');

$obj=new CrudKategori;
?>
                    <!-- DataTales Example -->
                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <a href="?halaman=tambah-kategori" class="btn btn-primary">Tambah</a>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                    <thead>
                                        <tr>
                                            <th>No</th>
                                            <th>Id</th>
                                            <th>Kategori</th>
                                            <th>Aksi</th>
                                        </tr>
                                    </thead>
                                    <tfoot>
                                        <tr>
                                            <th>No</th>
                                            <th>Id</th>
                                            <th>Kategori</th>
                                            <th>Aksi</th>
                                        </tr>
                                    </tfoot>
                                    <tbody>
                                        <?php

                                        $no=1;
                                        $data=$obj->tampilKategori(); while ($row=$data->fetch_array()){
                                            


                                            ?>
                                        <tr>
                                            <td>
                                                <?php echo $no++; ?>
                                            </td>
                                            <td>
                                                <?php echo $row['id']; ?>
                                            </td>
                                            <td>
                                                <?php echo $row['nama_kategori']; ?>
                                            </td>
                                            <td>

                                                <button class="btn btn-success"><a style="color:white;" href="?halaman=edit-buku&id=<?php echo $row['id']; ?>">Edit</a></button>
                                                <button class="btn btn-danger"><a style="color:white;" href="hapus-buku.php?id=<?php echo $row['id']; ?>" onclick="return confirm('Yakin Hapus?')">Hapus</a></button>
                                            </td>
                                        </tr>
                                        <?php
                                        }
                                        ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>

                </div>
                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->


        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>



