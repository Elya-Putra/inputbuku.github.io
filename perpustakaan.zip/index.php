<?php

session_start();
?>
<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Bootstrap demo</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
    <link rel="stylesheet" href="scss/style.css">
  </head>
  <body>

<header class="bg">
      <div class="full">
        <video loop muted autoplay>
          <source src="video/WhatsApp Video 2023-03-17 at 19.46.08.mp4" type="video/webm" />
        </video>
      </div>
  <div class="container">
    <div class="row intro">
      <div class="col-12 ">
        <h2>Website Input Buku</h2>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Cumque doloribus quos harum veritatis quod tempore nobis, vero dolore unde soluta recusandae reiciendis? Officia ipsam inventore aperiam aliquid in quis quam.</p>
        <button><a href="halaman-user.php">Masuk</a></button>
      </div>
    </div>
  </div>
</header>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4" crossorigin="anonymous"></script>
  </body>
</html>