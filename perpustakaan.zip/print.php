<?php
// memanggil library FPDF
require('fpdf/fpdf.php');
include 'konek.php';
 
// intance object dan memberikan pengaturan halaman PDF
$pdf=new FPDF('P','mm','A4');
$pdf->AddPage();

$pdf->SetFont('times','B',13);
$pdf->Cell(200,10,'DATA BUKU',0,0,'C');
 
$pdf->Cell(10,15,'',0,1);
$pdf->SetFont('Times','B',9);
$pdf->Cell(10,7,'NO',1,0,'C');
$pdf->Cell(10,7,'ID',1,0,'C');
$pdf->Cell(30,7,'JUDUL',1,0,'C');
$pdf->Cell(30,7,'PENERBIT' ,1,0,'C');
$pdf->Cell(30,7,'PENGARANG',1,0,'C');
$pdf->Cell(30,7,'TAHUN',1,0,'C');
$pdf->Cell(30,7,'KATEGORI',1,0,'C');
$pdf->Cell(20,7,'HARGA',1,0,'C');
 
 
$pdf->Cell(10,7,'',0,1);
$pdf->SetFont('Times','',10);
$no=1;
$data = mysqli_query($conn,"SELECT  * FROM buku");
while($d = mysqli_fetch_array($data)){
  $pdf->Cell(10,6, $no++,1,0,'C');
  $pdf->Cell(10,6, $d['id'],1,0,'C');
  $pdf->Cell(30,6, $d['judul'],1,0);  
  $pdf->Cell(30,6, $d['penerbit'],1,0);
  $pdf->Cell(30,6, $d['pengarang'],1,0);
  $pdf->Cell(30,6, $d['tahun'],1,0);  
  $pdf->Cell(30,6, $d['kategori_id'],1,0,'C'); 
  $pdf->Cell(20,6, $d['harga'],1,1);
}
 
$pdf->Output();
 
?>