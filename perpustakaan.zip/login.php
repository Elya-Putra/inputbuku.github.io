<?php
        require 'koneksi.php';

        if(isset($_SESSION["id"])){ 
          header("location:utama.php");
        }

        $login = new Login(); 
        if(isset($_POST["submit"])){
          $result = $login->loginan($_POST["username"], $_POST["password"], $_POST["level"]); 

          if($result==1){
        
        $_SESSION["login"]=true;
        $_SESSION["id"]=$login->idUser(); 
        header("location: halaman-admin.php");
        echo "<script>alert('Login Success');</script>";
        }elseif($result==10){
          echo "<script>alert('Wrong Password');</script>";
        }
        elseif($result==100){
          echo "<script>alert('User not register');</script>";
        }
        }
      ?>
<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Bootstrap demo</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
    <link rel="stylesheet" href="scss/style.css">
  </head>
  <body>
    <div class="container-fluid bg-login">
        <div class="row box-input">
            <form action="" method="POST">
            <h2>Silahkan Login</h2>
                <label for="username">Username</label><br>
                <input type="text" name="username" placeholder="Masukan username" required><br>
                <label for="password">Password</label><br>
                <input type="text" name="password" placeholder="Masukan password" required><br>
                <label for="">Level</label><br>
                <select name="level" id="">
                  <option value="">Pilih level</option>
                  <option value="Admin">Admin</option>
                  <option value="User">User</option>
                </select>
                <button class="btn" name="submit">Login</button>
            </form>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous"></script>
  </body>
</html>