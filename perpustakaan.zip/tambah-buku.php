<?php
    require 'koneksi.php';

    
    $obj=new CrudBuku(); 
    if(isset($_POST["submit"])){
      $query = $obj->insertBuku($_POST["id"], $_POST["judul"], $_POST["penerbit"], $_POST["pengarang"], $_POST["tahun"], $_POST["kategori_id"], $_POST["harga"]); 
    if($query>0){
      echo "<script>alert('Data Tersimpan');</script>";
      echo "<script>window.location='?halaman=tabel'</script>";
    }else{
        echo "error";
    }
    }
?>

<div class="container-fluid">

    <div class="card o-hidden border-0 shadow-lg">
        <div class="card-body p-0">
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-primary">Tambah Data Buku</h6>
                        </div>
            <!-- Nested Row within Card Body -->
            <div class="p-5">
                <form class="user" method="POST">
                    <div class="form-group row">
                        <div class="col-12">
                            <input type="hidden" class="form-control" id="exampleFirstName" name="id"
                                placeholder="Masukan Id">
                        </div>
                        <div class="col-sm-6 mb-3 mb-sm-0">
                            <input type="text" class="form-control" id="exampleLastName" name="judul"
                                placeholder="Masukan Judul">
                        </div>
                        <div class="col-sm-6">
                            <input type="text" class="form-control" id="exampleFirstName" name="penerbit"
                                placeholder="Masukan Penerbit">
                        </div>
                    </div>
                    <div class="form-group row">
                        <div class="col-sm-6 mb-3 mb-sm-0">
                            <input type="text" class="form-control" id="exampleLastName" name="pengarang"
                                placeholder="Masukan Pengarang">
                        </div>
                        <div class="col-sm-6">
                            <input type="text" class="form-control" id="exampleInputPassword" name="tahun"
                                placeholder=" Tahun">
                        </div>
                    </div>
                    <div class="form-group row">
                        <div class="col-sm-6 mb-3 mb-sm-0">
                            <select class="form-control" name="kategori_id">
                                <?php
                                $crudKategori = new CrudKategori();
                                $result = $crudKategori->tampilKategori();
                                while($row = mysqli_fetch_assoc($result)) {
                                    echo "<option value='" . $row['id'] . "'>" . $row['nama_kategori'] . "</option>";
                                }
                                ?>
                            </select>
                        </div>
                        <div class="col-sm-6 mb-3 mb-sm-0">
                            <input type="text" class="form-control" id="exampleInputPassword" name="harga"
                                placeholder=" Harga">
                        </div>
                        
                    </div>
                    
                    <button class="btn btn- btn-primary" name="submit" style="margin= auto;">Simpan</button>
                </form>
            </div>
        </div>
    </div>

</div>

<!-- Scroll to Top Button-->
<a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
</a>